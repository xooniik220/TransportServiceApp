# Transport Service Android App

Website: https://xooni16.github.io/xooni-transport/
App name: Transport Service
Package: com.transportservice.app
Target SDK: 36 (Android 16).

## Build
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Build > Generate Signed App Bundle / APK > Android App Bundle.
4. Create/sign a release AAB and upload it to Google Play Console.

The app requires internet access because its content loads from the website. Call/WhatsApp/Maps/mail links are opened through Android when tapped.
